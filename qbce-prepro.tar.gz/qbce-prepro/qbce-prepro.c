/*
 This file is part of qbce-prepro.

 Copyright 2017 
 Florian Lonsing, Vienna University of Technology, Austria.

 qbce-prepro is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or (at
 your option) any later version.

 qbce-prepro is distributed in the hope that it will be useful, but
 WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with qbce-prepro.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <sys/resource.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <dirent.h>
#include <assert.h>
#include <string.h>
#include <stdarg.h>
#include <signal.h>
#include <unistd.h>
#include "stack.h"
#include "mem.h"

/* -------------------- START: Helper macros -------------------- */

#define USAGE \
"usage: ./qbce-prepro [options] input-formula [timeout]\n"\
"\n"\
"  - 'input-formula' is a file in QDIMACS format (default: stdin)\n"\
"  - '[timeout]' is an optional timeout in seconds\n"\
"  - '[options]' is any combination of the following:\n\n"\
"    -h, --help         print this usage information and exit\n"\
"    --simplify         detect and mark blocked clauses\n"\
"    --print-formula    print parsed (and simplified) formula to stdout\n"\
"                         Note: if option '--simplify' is NOT given\n"\
"                         then the original formula is printed as is\n"\
"    -v                 increase verbosity level incrementally (default: 0)\n"\
"\n"

/* Macro to print message and abort. */
#define ABORT_APP(cond,msg)                                       \
  do {                                                                  \
    if (cond)                                                           \
      {                                                                 \
        fprintf (stderr, "[QBCE-PREPRO] %s at line %d: %s\n", __func__,   \
                 __LINE__, msg);                                        \
        fflush (stderr);                                                \
        abort();                                                        \
      }                                                                 \
  } while (0)

/* Generic macros to link and unlink elements from a doubly linked list.  */
#define LINK_LAST(anchor,element,link)		\
  do {						\
    assert (!(element)->link.prev);		\
    assert (!(element)->link.next);		\
    if ((anchor).last)				\
      {						\
        assert (!(anchor).last->link.next);	\
        assert ((anchor).first);                \
        assert (!(anchor).first->link.prev);	\
        (anchor).last->link.next = (element);	\
      }						\
    else                                        \
      {						\
        assert (!(anchor).first);		\
        (anchor).first = (element);		\
      }						\
    (element)->link.prev = (anchor).last;	\
    (anchor).last = (element);			\
    (anchor).cnt++;				\
  } while (0)

#define LINK_FIRST(anchor,element,link)		\
  do {						\
    assert (!(element)->link.prev);		\
    assert (!(element)->link.next);		\
    (element)->link.next = (anchor).first;	\
    if ((anchor).first)				\
      {						\
        assert ((anchor).last);			\
        (anchor).first->link.prev = (element);	\
      }						\
    else					\
      {						\
        assert (!(anchor).last);		\
        (anchor).last = (element);		\
      }						\
    (anchor).first = (element);			\
    (anchor).cnt++;				\
  } while (0)

#define UNLINK(anchor,element,link)				\
  do {								\
    assert ((anchor).cnt);					\
    if ((element)->link.prev)					\
      {								\
        assert ((anchor).first);                                \
        assert ((anchor).last);					\
        assert ((element)->link.prev->link.next == (element));	\
        (element)->link.prev->link.next = (element)->link.next; \
      }								\
    else                                                        \
      {								\
        assert ((anchor).first == (element));			\
        (anchor).first = (element)->link.next;			\
      }								\
    if ((element)->link.next)					\
      {								\
        assert ((anchor).first);                                \
        assert ((anchor).last);					\
        assert ((element)->link.next->link.prev == (element));	\
        (element)->link.next->link.prev = (element)->link.prev; \
      }								\
    else                                                        \
      {								\
        assert ((anchor).last == (element));			\
        (anchor).last = (element)->link.prev;			\
      }								\
    (element)->link.prev = (element)->link.next = 0;		\
    (anchor).cnt--;						\
  } while (0)

/* -------------------- END: Helper macros -------------------- */

/* -------- START: PCNF data structures -------- */

typedef struct PCNF PCNF;
typedef struct Scope Scope;
typedef struct Var Var;
typedef struct Clause Clause;

typedef int LitID;
typedef unsigned int VarID;
typedef unsigned int ClauseID;
typedef unsigned int Nesting;

enum QuantifierType
{
  QTYPE_EXISTS = -1,
  QTYPE_UNDEF = 0,
  QTYPE_FORALL = 1
};

typedef enum QuantifierType QuantifierType;

#define DECLARE_DLIST(name, type)					\
  struct name ## List {type * first; type * last; unsigned int cnt;};	\
  typedef struct name ## List name ## List				\

#define DECLARE_DLINK(name, type)			  \
  struct name ## Link {type * prev; type * next;};        \
  typedef struct name ## Link name ## Link                \

/* Declare lists and stacks of Scopes, Clauses, etc. */
DECLARE_DLINK (Scope, Scope);
DECLARE_DLIST (Scope, Scope);
DECLARE_DLINK (Clause, Clause);
DECLARE_DLIST (Clause, Clause);

DECLARE_STACK (VarID, VarID);
DECLARE_STACK (LitID, LitID);
DECLARE_STACK (ClausePtr, Clause *);
DECLARE_STACK (VarPtr, Var *);

/* PCNF object, defined by list of scopes (quantifier prefix), array of
   variable objects (variable is indexed by its QDIMACS ID), and doubly linked
   list of clauses. */
struct PCNF
{
  ScopeList scopes;
  /* Size of var-table. */
  VarID size_vars;
  /* Table of variable objects indexed by unsigned integer ID. */
  Var *vars;
  ClauseList clauses;
};

/* Scope object (quantifier block in the quantifier prefix). */
struct Scope
{
  QuantifierType type;
  /* Scopes have nesting level, starting at 0, increases by one from left to
     right. */
  unsigned int nesting;
  /* IDs of variables in a scope are kept on a stack. */
  VarIDStack vars;
  /* Scopes appear in a doubly linked list. */
  ScopeLink link;
};

/* Variable object. */
struct Var
{
  /* ID of a variable is used as index to access the array of variable objects. */
  VarID id;
  /* Two multi-purpose marks. */
  unsigned int mark0:1;
  unsigned int mark1:1;

  /* Stacks with pointers to clauses containing positive and negative literals
     of the variable. */
  ClausePtrStack neg_occ_clauses;
  ClausePtrStack pos_occ_clauses;

  /* Pointer to scope of variable. */
  Scope *scope;
};

/* Clause object. */
struct Clause
{
  /* Clauses get a unique ID. This is mainly for debugging. */
  ClauseID id;
  /* Number of literals in a clause, i.e. its size. */
  unsigned int num_lits;

  /* Mark indicating that clause is blocked and hence redundant. */
  unsigned int blocked:1;
  /* Multi-purpose mark. */
  unsigned int mark:1;

  /* All  clauses are kept in a doubly linked list. */
  ClauseLink link;

  /* Flexible literal array. DO NOT ADD MEMBERS AFTER 'lits[]'! (violation of
     C99 standard). */
  LitID lits[];
};

/* Some helper macros. */

/* Check if literal is positive or negative. */
#define LIT_NEG(lit) ((lit) < 0)
#define LIT_POS(lit) (!LIT_NEG((lit)))

/* Convert literal to variable ID or to pointer to variable object. */
#define LIT2VARID(lit) ((lit) < 0 ? -(lit) : (lit))
#define LIT2VARPTR(vars, lit) ((vars) + LIT2VARID(lit))
#define LIT2VAR(vars, lit) ((vars)[LIT2VARID(lit)])

/* Convert variable ID to pointer to variable object. */
#define VARID2VARPTR(vars, id) ((vars) + (id))

/* Check if scope is existential or universal. */
#define SCOPE_EXISTS(s) ((s)->type == QTYPE_EXISTS)
#define SCOPE_FORALL(s) ((s)->type == QTYPE_FORALL)

/* Mark/unmark variable by (re-)setting its positive or negative mark. */
#define VAR_POS_MARK(v) ((v)->mark0 = 1)
#define VAR_NEG_MARK(v) ((v)->mark1 = 1)
#define VAR_UNMARK(v) ((v)->mark0 = (v)->mark1 = 0)
#define VAR_POS_MARKED(v) ((v)->mark0)
#define VAR_NEG_MARKED(v) ((v)->mark1)
#define VAR_MARKED(v) ((v)->mark0 || (v)->mark1)

/* -------- END: PCNF data structures -------- */

/* -------- START: Application defintions and functions -------- */

/* QBCEPrepro object. This is used by the main application. */
struct QBCEPrepro
{
  /* PCNF object representing the parsed formula. */
  PCNF pcnf;
  /* Simple memory manager. */
  MemMan *mm;
  /* Declared number of clauses in QDIMACS file. */
  unsigned int declared_num_clauses;
  /* Number of blocked clauses. */
  unsigned int cnt_blocked_clauses;
  /* Number of QBCE iterations. */
  unsigned int cnt_qbce_iterations;
  /* Number of QBCE checks. */
  long long unsigned int cnt_qbce_checks;
  /* Stack of literals or variable IDs read during parsing. */
  LitIDStack parsed_literals;
  /* Pointer to most recently opened scope during parsing. */
  Scope *opened_scope;
  /* Every clause gets a unique ID (for debugging purposes). */
  ClauseID cur_clause_id;
  /* Auxiliary stack to store clauses which were found to be blocked. */
  ClausePtrStack blocked_clauses;
  /* Start time of program. */
  double start_time;

  /* Options to be set via command line. */
  struct
  {
    char *in_filename;
    FILE *in;
    unsigned int max_time;
    unsigned int verbosity;
    unsigned int print_usage;
    unsigned int simplify;
    unsigned int print_formula;
  } options;
};

typedef struct QBCEPrepro QBCEPrepro;

/* Print error message. */
static void
print_abort_err (char *msg, ...)
{
  va_list list;
  assert (msg != NULL);
  fprintf (stderr, "qbce-prepro: ");
  va_start (list, msg);
  vfprintf (stderr, msg, list);
  va_end (list);
  fflush (stderr);
  abort ();
}

/* Print array 'lits' of literals of length 'num'. If 'print_info' is
non-zero, then print info about the scope of each literal in the array. */
static void
print_lits (QBCEPrepro * qr, FILE * out, LitID * lits, unsigned int num,
            const int print_info)
{
  Var *vars = qr->pcnf.vars;
  LitID *p, *e;
  for (p = lits, e = p + num; p < e; p++)
    {
      LitID lit = *p;
      Var *var = LIT2VARPTR (vars, lit);
      if (print_info)
        fprintf (out, "%c(%d)%d ",
                 SCOPE_FORALL (var->scope) ? 'A' : 'E',
                 var->scope->nesting, *p);
      else
        fprintf (out, "%d ", *p);
    }
  fprintf (out, "0\n");
}

/* -------- END: Application defintions and functions -------- */

/* -------------------- START: QDIMACS PARSING -------------------- */

/* Allocate table of variable IDs having fixed size. If the preamble of the
   QDIMACS file specifies a maximum variable ID which is smaller than the ID
   of a variable encountered in the formula, then the program aborts. */
static void
set_up_var_table (QBCEPrepro * qr, int num)
{
  assert (num >= 0);
  assert (!qr->pcnf.size_vars);
  qr->pcnf.size_vars = num + 1;
  assert (!qr->pcnf.vars);
  qr->pcnf.vars =
    (Var *) mm_malloc (qr->mm, qr->pcnf.size_vars * sizeof (Var));
}

/* Allocate a new scope object and append it to the list of scopes. */
static void
open_new_scope (QBCEPrepro * qr, QuantifierType scope_type)
{
  Scope *scope = mm_malloc (qr->mm, sizeof (Scope));
  scope->type = scope_type;
  scope->nesting = qr->pcnf.scopes.last ?
    qr->pcnf.scopes.last->nesting + 1 : 0;
  assert (!qr->opened_scope);
  /* Keep pointer to opened scope to add parsed variable IDs afterwards. */
  qr->opened_scope = scope;
  /* Append scope to list of scopes. */
  LINK_LAST (qr->pcnf.scopes, scope, link);
}

/* Abort if clause contains complementary literals (i.e. clause is
   tautological) or multiple literals of the same variable. (Alternatively,
   tautological clauses or multiple literals could be discarded. However, for
   simplicity, the program will abort.) */
static void
check_and_add_clause (QBCEPrepro * qr, Clause * clause)
{
  /* Add parsed literals to allocated clause object 'clause'. */
  LitID *p, *e, *clause_lits_p = clause->lits;
  for (p = qr->parsed_literals.start, e = qr->parsed_literals.top; p < e; p++)
    {
      LitID lit = *p;
      VarID varid = LIT2VARID (lit);
      ABORT_APP (varid >= qr->pcnf.size_vars,
                       "variable ID in clause exceeds max. ID given in preamble!");
      Var *var = LIT2VARPTR (qr->pcnf.vars, lit);
      ABORT_APP (!var->scope,
                       "variable has not been declared in a scope!");

      /* Check for complementary and multiple occurrences of literals. */
      if (VAR_POS_MARKED (var))
        {
          ABORT_APP (LIT_POS (lit),
                           "literal has multiple positive occurrences!");
          ABORT_APP (LIT_NEG (lit),
                           "literal has complementary occurrences!");
        }
      else if (VAR_NEG_MARKED (var))
        {
          ABORT_APP (LIT_NEG (lit),
                           "literal has multiple negative occurrences!");
          ABORT_APP (LIT_POS (lit),
                           "literal has complementary occurrences!");
        }
      else
        {
          assert (!VAR_MARKED (var));
          if (LIT_NEG (lit))
            VAR_NEG_MARK (var);
          else
            VAR_POS_MARK (var);
        }

      assert (clause_lits_p < clause->lits + clause->num_lits);
      /* Add literal to clause object. */
      *clause_lits_p++ = *p;
      /* Push clause object on stack of occurrences. */
      if (LIT_NEG (lit))
        PUSH_STACK (qr->mm, var->neg_occ_clauses, clause);
      else
        PUSH_STACK (qr->mm, var->pos_occ_clauses, clause);
    }

  /* NOTE: literals in clauses are neither sorted nor universal-reduced,
     i.e. they appear in the clause as they are given in the QDIMACS file. */

  /* Unmark variables. */
  for (p = qr->parsed_literals.start, e = qr->parsed_literals.top; p < e; p++)
    VAR_UNMARK (LIT2VARPTR (qr->pcnf.vars, *p));

  /* Append clause to list of clauses. */
  LINK_LAST (qr->pcnf.clauses, clause, link);
}

/* Check and add a parsed clause to the PCNF data structures. */
static void
import_parsed_clause (QBCEPrepro * qr)
{
  assert (!qr->opened_scope);
  /* Allocate new clause object capable of storing 'num_lits' literals. The
     literals on the stack 'parsed_literals' will be copied to the new clause
     object. */
  int num_lits = COUNT_STACK (qr->parsed_literals);
  Clause *clause = mm_malloc (qr->mm, sizeof (Clause) +
                              num_lits * sizeof (LitID));
  clause->id = ++qr->cur_clause_id;
  ABORT_APP (clause->id > qr->declared_num_clauses,
                   "actual number of clauses exceeds declared number of clauses!");
  clause->num_lits = num_lits;

  /* Add the parsed clause to the formula and to the stacks of variable
     occurrences, provided that it does not contain complementary or multiple
     literals of the same variable. */
  check_and_add_clause (qr, clause);

  if (qr->options.verbosity >= 2)
    {
      fprintf (stderr, "Imported clause: ");
      print_lits (qr, stderr, clause->lits, clause->num_lits, 1);
    }
}

/* Add parsed scope to data structures. */
static void
import_parsed_scope_variables (QBCEPrepro * qr)
{
  assert (qr->opened_scope);
  assert (EMPTY_STACK (qr->opened_scope->vars));
  LitID *p, *e;
  for (p = qr->parsed_literals.start, e = qr->parsed_literals.top; p < e; p++)
    {
      LitID varid = *p;
      ABORT_APP (varid <= 0,
                       "variable ID in scope must be positive!\n");
      ABORT_APP ((VarID) varid >= qr->pcnf.size_vars,
                       "variable ID in scope exceeds max. ID given in preamble!");

      /* Add variable ID to list of IDs in the scope. */
      PUSH_STACK (qr->mm, qr->opened_scope->vars, varid);
      Var *var = VARID2VARPTR (qr->pcnf.vars, varid);
      /* Set variable ID and pointer to scope of variable. */
      ABORT_APP (var->id, "variable already quantified!\n");
      var->id = varid;
      assert (!var->scope);
      var->scope = qr->opened_scope;
    }
  /* The current scope has been added to the scope list already. */
  assert (qr->opened_scope == qr->pcnf.scopes.first ||
          (qr->opened_scope->link.prev && !qr->opened_scope->link.next));
  assert (qr->opened_scope != qr->pcnf.scopes.first ||
          (!qr->opened_scope->link.prev && !qr->opened_scope->link.next));
}

/* Collect parsed literals of a scope or a clause on auxiliary stack to be
   imported and added to data structures later. */
static void
collect_parsed_literal (QBCEPrepro * qr, int num)
{
  if (num == 0)
    {
      if (qr->opened_scope)
        {
          import_parsed_scope_variables (qr);
          qr->opened_scope = 0;
        }
      else
        import_parsed_clause (qr);
      RESET_STACK (qr->parsed_literals);
    }
  else
    PUSH_STACK (qr->mm, qr->parsed_literals, num);
}

#define PARSER_READ_NUM(num, c)                        \
  assert (isdigit (c));                                \
  num = 0;					       \
  do						       \
    {						       \
      num = num * 10 + (c - '0');		       \
    }						       \
  while (isdigit ((c = getc (in))));

#define PARSER_SKIP_SPACE_DO_WHILE(c)		     \
  do						     \
    {                                                \
      c = getc (in);				     \
    }                                                \
  while (isspace (c));

#define PARSER_SKIP_SPACE_WHILE(c)		     \
  while (isspace (c))                                \
    c = getc (in);

static void
parse (QBCEPrepro * qr, FILE * in)
{
  int neg = 0, preamble_found = 0;
  LitID num = 0;
  QuantifierType scope_type = QTYPE_UNDEF;

  assert (in);

  int c;
  while ((c = getc (in)) != EOF)
    {
      PARSER_SKIP_SPACE_WHILE (c);

      while (c == 'c')
        {
          while ((c = getc (in)) != '\n' && c != EOF)
            ;
          c = getc (in);
        }

      PARSER_SKIP_SPACE_WHILE (c);

      if (c == 'p')
        {
          /* parse preamble */
          PARSER_SKIP_SPACE_DO_WHILE (c);
          if (c != 'c')
            goto MALFORMED_PREAMBLE;
          PARSER_SKIP_SPACE_DO_WHILE (c);
          if (c != 'n')
            goto MALFORMED_PREAMBLE;
          PARSER_SKIP_SPACE_DO_WHILE (c);
          if (c != 'f')
            goto MALFORMED_PREAMBLE;
          PARSER_SKIP_SPACE_DO_WHILE (c);
          if (!isdigit (c))
            goto MALFORMED_PREAMBLE;

          /* Read number of variables */
          PARSER_READ_NUM (num, c);

          /* Allocate array of variable IDs of size 'num + 1', since 0 is an
             invalid variable ID. */
          set_up_var_table (qr, num);

          PARSER_SKIP_SPACE_WHILE (c);
          if (!isdigit (c))
            goto MALFORMED_PREAMBLE;

          /* Read number of clauses */
          PARSER_READ_NUM (num, c);

          qr->declared_num_clauses = num;

          if (qr->options.verbosity >= 1)
            fprintf (stderr, "parsed preamble: p cnf %d %d\n",
                     (qr->pcnf.size_vars - 1), qr->declared_num_clauses);

          preamble_found = 1;
          goto PARSE_SCOPE_OR_CLAUSE;

        MALFORMED_PREAMBLE:
          ABORT_APP (1, "malformed preamble!\n");
          return;
        }
      else
        {
          ABORT_APP (1, "expecting preamble!\n");
          return;
        }

    PARSE_SCOPE_OR_CLAUSE:

      PARSER_SKIP_SPACE_WHILE (c);

      if (c == 'a' || c == 'e')
        {
          /* Open a new scope */
          if (c == 'a')
            scope_type = QTYPE_FORALL;
          else
            scope_type = QTYPE_EXISTS;

          ABORT_APP (qr->opened_scope,
                           "must close scope by '0' before opening a new scope!\n");

          open_new_scope (qr, scope_type);

          PARSER_SKIP_SPACE_DO_WHILE (c);
        }

      if (!isdigit (c) && c != '-')
        {
          if (c == EOF)
            return;
          ABORT_APP (1, "expecting digit or '-'!\n");
          return;
        }
      else
        {
          if (c == '-')
            {
              neg = 1;
              if (!isdigit ((c = getc (in))))
                {
                  ABORT_APP (1, "expecting digit!\n");
                  return;
                }
            }

          /* parse a literal or variable ID */
          PARSER_READ_NUM (num, c);
          num = neg ? -num : num;

          collect_parsed_literal (qr, num);

          neg = 0;

          goto PARSE_SCOPE_OR_CLAUSE;
        }
    }

  if (!preamble_found)
    ABORT_APP (1, "preamble missing!\n");
}

/* -------------------- END: QDIMACS PARSING -------------------- */

/* -------------------- START: COMMAND LINE PARSING -------------------- */
static void
set_default_options (QBCEPrepro * qr)
{
  qr->options.in_filename = 0;
  qr->options.in = stdin;
  qr->options.print_usage = 0;
}

static int
isnumstr (char *str)
{
  /* Empty string is not considered as number-string. */
  if (!*str)
    return 0;
  char *p;
  for (p = str; *p; p++)
    {
      if (!isdigit (*p))
        return 0;
    }
  return 1;
}

/* Parse command line arguments to set options accordingly. Run the program
   with '-h' or '--help' to print usage information. */
static void
parse_cmd_line_options (QBCEPrepro * qr, int argc, char **argv)
{
  char *result;
  int opt_cnt;
  for (opt_cnt = 1; opt_cnt < argc; opt_cnt++)
    {
      char *opt_str = argv[opt_cnt];

      if (!strcmp (opt_str, "-h") || !strcmp (opt_str, "--help"))
        {
          qr->options.print_usage = 1;
        }
      else if (!strcmp (opt_str, "--simplify"))
        {
          qr->options.simplify = 1;
        }
      else
        if (!strncmp (opt_str, "--print-formula", strlen ("--print-formula")))
        {
          qr->options.print_formula = 1;
        }
      else if (!strcmp (opt_str, "-v"))
        {
          qr->options.verbosity++;
        }
      else if (isnumstr (opt_str))
        {
          qr->options.max_time = atoi (opt_str);
          if (qr->options.max_time == 0)
            {
              result = "Expecting non-zero value for max-time";
              print_abort_err ("%s!\n\n", result);
            }
        }
      else if (!qr->options.in_filename)
        {
          qr->options.in_filename = opt_str;
          /* Check input file. */
          DIR *dir;
          if ((dir = opendir (qr->options.in_filename)) != NULL)
            {
              closedir (dir);
              print_abort_err ("input file '%s' is a directory!\n\n",
                               qr->options.in_filename);
            }
          FILE *input_file = fopen (qr->options.in_filename, "r");
          if (!input_file)
            {
              print_abort_err ("could not open input file '%s'!\n\n",
                               qr->options.in_filename);
            }
          else
            qr->options.in = input_file;
        }
      else
        {
          print_abort_err ("unknown option '%s'!\n\n", opt_str);
        }
    }
}

/* -------------------- END: COMMAND LINE PARSING -------------------- */

/* -------------------- START: HELPER FUNCTIONS -------------------- */

/* Set signal handler. */
static void
sig_handler (int sig)
{
  fprintf (stderr, "\n\n SIG RECEIVED\n\n");
  signal (sig, SIG_DFL);
  raise (sig);
}

/* Set signal handler. */
static void
sigalrm_handler (int sig)
{
  fprintf (stderr, "\n\n SIGALRM RECEIVED\n\n");
  signal (sig, SIG_DFL);
  raise (sig);
}

/* Set signal handler. */
static void
set_signal_handlers (void)
{
  signal (SIGINT, sig_handler);
  signal (SIGTERM, sig_handler);
  signal (SIGALRM, sigalrm_handler);
  signal (SIGXCPU, sigalrm_handler);
}

static void
print_usage ()
{
  fprintf (stdout, USAGE);
}

/* Free allocated memory. */
static void
cleanup (QBCEPrepro * qr)
{
  if (qr->options.in_filename)
    fclose (qr->options.in);

  DELETE_STACK (qr->mm, qr->parsed_literals);
  DELETE_STACK (qr->mm, qr->blocked_clauses);

  Var *vp, *ve;
  for (vp = qr->pcnf.vars, ve = vp + qr->pcnf.size_vars; vp < ve; vp++)
    {
      DELETE_STACK (qr->mm, vp->pos_occ_clauses);
      DELETE_STACK (qr->mm, vp->neg_occ_clauses);
    }
  mm_free (qr->mm, qr->pcnf.vars, qr->pcnf.size_vars * sizeof (Var));

  Scope *s, *sn;
  for (s = qr->pcnf.scopes.first; s; s = sn)
    {
      sn = s->link.next;
      DELETE_STACK (qr->mm, s->vars);
      mm_free (qr->mm, s, sizeof (Scope));
    }

  Clause *c, *cn;
  for (c = qr->pcnf.clauses.first; c; c = cn)
    {
      cn = c->link.next;
      mm_free (qr->mm, c, sizeof (Clause) + c->num_lits * sizeof (LitID));
    }
}

/* Print (simplified) formula to file 'out'. If '--simplify'
   is specified then blocked clauses will not be printed. */
static void
print_formula (QBCEPrepro * qr, FILE * out)
{
  assert (qr->pcnf.clauses.cnt >= qr->cnt_blocked_clauses);
  /* Print preamble. */
  assert (qr->pcnf.size_vars > 0);
  fprintf (out, "p cnf %d %d\n", (qr->pcnf.size_vars - 1),
           (qr->pcnf.clauses.cnt - qr->cnt_blocked_clauses));

  /* Print prefix. */
  Scope *s;
  for (s = qr->pcnf.scopes.first; s; s = s->link.next)
    {
      fprintf (out, "%c ", SCOPE_FORALL (s) ? 'a' : 'e');
      print_lits (qr, out, (LitID *) s->vars.start,
                  COUNT_STACK (s->vars), 0);
    }

  /* Print clauses. */
  Clause *c;
  for (c = qr->pcnf.clauses.first; c; c = c->link.next)
    if (!c->blocked)
      print_lits (qr, out, c->lits, c->num_lits, 0);
}

/* Get process time. Can be used for performance statistics. */
static double
time_stamp ()
{
  double result = 0;
  struct rusage usage;

  if (!getrusage (RUSAGE_SELF, &usage))
    {
      result += usage.ru_utime.tv_sec + 1e-6 * usage.ru_utime.tv_usec;
      result += usage.ru_stime.tv_sec + 1e-6 * usage.ru_stime.tv_usec;
    }

  return result;
}

/* -------------------- END: HELPER FUNCTIONS -------------------- */

/* -------------------- START: QBCE -------------------- */

/* Returns true if and only if 'lit' appears in the literal array bounded by
   'start' and 'end' (position 'end' is not part of the array). */
static int
find_literal (LitID lit, LitID * start, LitID * end)
{
  LitID *p;
  for (p = start; p < end; p++)
    if (*p == lit)
      return 1;
  return 0;
}

/* Return nonzero iff resolvent of 'c' and 'occ' on literal 'lit' is
   tautologous with respect to a variable that is smaller than or
   equal to 'lit' in the prefix ordering. 
   NOTE / POSSIBLE OPTIMIZATION: literals in clauses are neither sorted
   nor universal-reduced, i.e. they appear in the clause as they are
   given in the QDIMACS file. */
static int
check_outer_tautology (QBCEPrepro * qr, Clause *c, LitID lit, Clause *occ)
{
  assert (!c->blocked);
  assert (!occ->blocked);
  assert (c->num_lits > 0);
  assert (occ->num_lits > 0);
  Var *var = LIT2VARPTR (qr->pcnf.vars, lit);
  Scope *scope = var->scope;
  assert(scope->type == QTYPE_EXISTS);
  Nesting nesting = scope->nesting;
  /* Literal 'lit' must appear in complementary phases in clauses 'c'
     and 'occ'. */
  assert (find_literal (lit, c->lits, c->lits + c->num_lits));
  assert (find_literal (-lit, occ->lits, occ->lits + occ->num_lits));

  //TODO optimization here: mark all literals in 'c' and then traverse
  //'occ' once to search for marked complementary literal with
  //appropriate prefix position.

  //TODO: if all clauses are sorted by prefix ordering, then we can
  //abort search for tautology literals earlier.

  LitID *cp, *ce;
  for (cp = c->lits, ce = cp + c->num_lits; cp < ce; cp++)
    {
      LitID cl = *cp;
      /* Must ignore potential blocking literal 'lit'. */
      if (cl != lit)
        {
          /* Must consider only tautologies due to literals with
             nesting level smaller than or equal to nesting of
             'lit'. Check whether other clause 'occ' contains
             complementary literal '-cl'. */
          Var *cv = LIT2VARPTR (qr->pcnf.vars, cl);
          if (cv->scope->nesting <= nesting && 
              find_literal (-cl, occ->lits, occ->lits + occ->num_lits))
            return 1;
        }
    }
  return 0;
}

/* Return nonzero iff 'lit' is a blocking literal in clause 'c'. */
static int
is_literal_blocking (QBCEPrepro * qr, Clause *c, LitID lit)
{
  assert (!c->blocked);
  assert (c->num_lits > 0);
  Var *var = LIT2VARPTR (qr->pcnf.vars, lit);
  assert(var->scope->type == QTYPE_EXISTS);
  assert (LIT_NEG (lit) || LIT_POS (lit));
  /* Set pointer to stack of clauses containing literals complementary to 'lit'. */
  ClausePtrStack *comp_occs = LIT_NEG (lit) ? 
    &(var->pos_occ_clauses) : &(var->neg_occ_clauses);

  /* Check all possible resolution candidates on literal 'lit' and
     clauses on 'comp_occs'. Must ignore already blocked
     occurrences. */
  Clause **occ_p, **occ_e;
  for (occ_p = comp_occs->start, occ_e = comp_occs->top; occ_p < occ_e; occ_p++)
    {
     Clause *occ = *occ_p; 
     if (!occ->blocked && !check_outer_tautology (qr, c, lit, occ))
       return 0;
    }
  /* All candidates fulfill tautology property of QBCE, hence 'lit' 
     is blocking literal in clause 'c'. */
  return 1;
}

/* Return nonzero iff clause 'c' is blocked. */
static int
is_clause_blocked (QBCEPrepro * qr, Clause *c)
{
  assert (!c->blocked);
  LitID *p, *e;
  for (p = c->lits, e = p + c->num_lits; p < e; p++)
    {
      LitID lit = *p;
      Var *var = LIT2VARPTR (qr->pcnf.vars, lit);
      /* Check if existential literal 'lit' is indeed a blocking literal. */
      if (var->scope->type == QTYPE_EXISTS)
        {
          if (is_literal_blocking (qr, c, lit))
            return 1;
        }
    }
  return 0;
}

/* A very inefficient implementation of QBCE. */
static void
find_and_mark_blocked_clauses (QBCEPrepro * qr)
{
  unsigned int cur_blocked_clauses = 0;
  int changed = 1;
  while (changed)
    {
      qr->cnt_blocked_clauses += cur_blocked_clauses;
      qr->cnt_qbce_iterations++;
      if (qr->options.verbosity >= 1)
        fprintf (stderr, "QBCE iteration: %d with %d blocked clauses in last iteration\n", 
                 qr->cnt_qbce_iterations, cur_blocked_clauses);
      cur_blocked_clauses = 0;
      changed = 0;
      Clause *c;
      for (c = qr->pcnf.clauses.first; c; c = c->link.next)
        {
          if (!c->blocked)
            {
              qr->cnt_qbce_checks++;
              /* Print progress information. */
              if (qr->options.verbosity >= 1 && 
                  (qr->cnt_qbce_checks & ((1 << 15) - 1)) == 0)
                fprintf (stderr, "progress -- QBCE checks: %llu\n", 
                         qr->cnt_qbce_checks);
              if (is_clause_blocked (qr, c))
                {
                  c->blocked = 1;
                  cur_blocked_clauses++;
                  changed = 1;
                }
            }
        }
    }
}

/* -------------------- END: QBCE -------------------- */


int
main (int argc, char **argv)
{
  double start_time = time_stamp ();
  int result = 0;
  /* Initialize QBCEPrepro object. */
  QBCEPrepro qr;
  memset (&qr, 0, sizeof (QBCEPrepro));
  qr.start_time = start_time;
  /* Initialize simple memory manager. */
  MemMan *mm = mm_create ();
  qr.mm = mm;
  set_default_options (&qr);

  parse_cmd_line_options (&qr, argc, argv);
  set_signal_handlers ();

  if (qr.options.print_usage)
    {
      print_usage ();
      cleanup (&qr);
      return result;
    }

  if (qr.options.max_time)
    {
      fprintf (stderr, "Setting run time limit of %d seconds\n",
               qr.options.max_time);
      alarm (qr.options.max_time);
    }

  /* Parse QDIMACS formula and simplify, if appropriate command line options
     are given. */
  parse (&qr, qr.options.in);
  ABORT_APP (qr.declared_num_clauses > qr.cur_clause_id,
                   "declared number of clauses exceeds actual number of clauses!");

  if (qr.options.simplify)
    find_and_mark_blocked_clauses (&qr);

  /* Print formula to stdout. */
  if (qr.options.print_formula)
    print_formula (&qr, stdout);

  if (qr.options.verbosity >= 1)
    {
      /* Print statistics. */
      fprintf (stderr, "\nDONE, printing statistics:\n");
      if (!qr.options.max_time)
        fprintf (stderr, "  time limit: not set\n");
      else
        fprintf (stderr, "  time limit: %d\n", qr.options.max_time);
      fprintf (stderr, "  simplification enabled: %s\n",
               qr.options.simplify ? "yes" : "no");
      fprintf (stderr, "  printing formula: %s\n",
               qr.options.print_formula ? "yes" : "no");
      fprintf (stderr, "  QBCE iterations: %d\n", qr.cnt_qbce_iterations);
      fprintf (stderr, "  QBCE checks: %llu ( %f %% of initial CNF)\n", 
               qr.cnt_qbce_checks, qr.declared_num_clauses ? 
               ((qr.cnt_qbce_checks / (float)qr.declared_num_clauses) * 100) : 0);
      fprintf (stderr, "  QBCE: %d blocked clauses of total %d clauses ( %f %% of initial CNF)\n",
               qr.cnt_blocked_clauses, qr.declared_num_clauses, qr.declared_num_clauses ? 
               ((qr.cnt_blocked_clauses / (float)qr.declared_num_clauses) * 100) : 0);
      fprintf (stderr, "  run time: %f\n", time_stamp () - qr.start_time);
    }

  /* Clean up, free memory and exit. */
  cleanup (&qr);
  mm_delete (qr.mm);

  return result;
}
